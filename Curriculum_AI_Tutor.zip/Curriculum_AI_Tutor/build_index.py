from __future__ import annotations

from src.chunker import TextChunker
from src.cleaner import TextCleaner
from src.config import get_config
from src.corpus_builder import CorpusBuilder
from src.downloader import TextbookDownloader
from src.embeddings import EmbeddingGenerator
from src.parser import PDFParser
from src.utils import get_logger, set_global_seed
from src.vector_store import FAISSVectorStore


def main() -> None:
    config = get_config()
    set_global_seed(config.models.random_seed)
    logger = get_logger("build_index", config.paths.logs_dir)

    logger.info("Step 1: Obtaining textbook PDF")
    downloader = TextbookDownloader(config)
    pdf_path = downloader.obtain_pdf()

    logger.info("Step 2: Parsing PDF text")
    parser = PDFParser(config)
    pages = parser.parse(pdf_path)

    logger.info("Step 3: Cleaning text")
    cleaner = TextCleaner(config)
    cleaned_pages = cleaner.clean_pages(pages)

    logger.info("Step 4: Detecting chapters, sections, and chunking")
    chunker = TextChunker(config)
    chunks = chunker.chunk_pages(cleaned_pages)

    logger.info("Step 5: Writing cleaned corpus to JSONL")
    corpus_builder = CorpusBuilder(config)
    corpus_builder.write_jsonl(chunks)

    logger.info("Step 6: Generating embeddings")
    embedder = EmbeddingGenerator(config)
    texts = [chunk.text for chunk in chunks]
    embeddings = embedder.encode(texts)

    logger.info("Step 7: Building and persisting FAISS index")
    metadata_records = [
        {
            "chunk_id": chunk.chunk_id,
            "chapter": chunk.chapter,
            "section": chunk.section,
            "page": chunk.page,
            "text": chunk.text,
        }
        for chunk in chunks
    ]
    vector_store = FAISSVectorStore(config)
    vector_store.build(embeddings, metadata_records)
    vector_store.persist()

    logger.info("Index build complete. Total chunks indexed: %d", len(chunks))


if __name__ == "__main__":
    main()
