from __future__ import annotations

import streamlit as st

from src.config import get_config
from src.embeddings import EmbeddingGenerator
from src.llm import build_llm_client
from src.logger import InteractionLogger
from src.memory import ConversationMemory
from src.rag_pipeline import RAGPipeline
from src.retriever import FAISSRetriever
from src.utils import set_global_seed
from src.vector_store import FAISSVectorStore

st.set_page_config(page_title="NCERT Class 8 Science AI Tutor", layout="wide")


@st.cache_resource(show_spinner=False)
def load_config():
    config = get_config()
    set_global_seed(config.models.random_seed)
    return config


@st.cache_resource(show_spinner=False)
def load_embedder(_config):
    return EmbeddingGenerator(_config)


@st.cache_resource(show_spinner=False)
def load_vector_store(_config):
    store = FAISSVectorStore(_config)
    store.load()
    return store


def build_pipeline(config, provider: str, api_key: str) -> RAGPipeline | None:
    import os

    os.environ["LLM_PROVIDER"] = provider
    if api_key:
        os.environ["OPENAI_API_KEY"] = api_key

    try:
        embedder = load_embedder(config)
        vector_store = load_vector_store(config)
    except FileNotFoundError as exc:
        st.error(str(exc))
        return None

    retriever = FAISSRetriever(config, embedder, vector_store)

    try:
        from src.config import get_config as reload_config

        fresh_config = reload_config()
        llm_client = build_llm_client(fresh_config)
    except Exception as exc:
        st.error(f"Failed to initialize LLM provider '{provider}': {exc}")
        return None

    interaction_logger = InteractionLogger(config)
    memory = st.session_state.get("memory", ConversationMemory())
    st.session_state["memory"] = memory
    return RAGPipeline(config, retriever, llm_client, interaction_logger, memory)


def main() -> None:
    config = load_config()

    st.title("NCERT Class 8 Science AI Tutor")
    st.caption("Ask questions strictly from the NCERT Class 8 Science textbook.")

    with st.sidebar:
        st.header("Settings")
        api_key_input = st.text_input("OpenAI API Key", type="password", value="")
        provider = st.selectbox(
            "Model",
            options=["openai", "llama", "flan-t5-base", "flan-t5-lora"],
            index=0,
        )
        top_k = st.slider("Number of retrieved chunks (Top K)", min_value=1, max_value=10, value=4)
        if st.button("Clear Chat"):
            st.session_state["chat_history"] = []
            if "memory" in st.session_state:
                st.session_state["memory"].clear()
            st.rerun()

    if "chat_history" not in st.session_state:
        st.session_state["chat_history"] = []

    question = st.chat_input("Ask a question about NCERT Class 8 Science")

    for entry in st.session_state["chat_history"]:
        with st.chat_message("user"):
            st.write(entry["question"])
        with st.chat_message("assistant"):
            st.write(entry["answer"])
            if entry["sources"]:
                with st.expander("Retrieved Sources and Similarity Scores"):
                    for source in entry["sources"]:
                        st.markdown(
                            f"- **Chapter:** {source['chapter']} | "
                            f"**Section:** {source['section']} | "
                            f"**Page:** {source['page']} | "
                            f"**Similarity:** {source['score']}"
                        )

    if question:
        with st.chat_message("user"):
            st.write(question)

        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                pipeline = build_pipeline(config, provider, api_key_input)
                if pipeline is None:
                    st.error("Pipeline could not be initialized. Check configuration and try again.")
                    return
                try:
                    response = pipeline.answer(question, top_k=top_k)
                except Exception as exc:
                    st.error(f"An error occurred while generating the answer: {exc}")
                    return

            st.write(response.answer)
            sources = [
                {
                    "chapter": chunk.chapter,
                    "section": chunk.section,
                    "page": chunk.page,
                    "score": chunk.similarity_score,
                }
                for chunk in response.retrieved_chunks
            ]
            if sources:
                with st.expander("Retrieved Sources and Similarity Scores"):
                    for source in sources:
                        st.markdown(
                            f"- **Chapter:** {source['chapter']} | "
                            f"**Section:** {source['section']} | "
                            f"**Page:** {source['page']} | "
                            f"**Similarity:** {source['score']}"
                        )

        st.session_state["chat_history"].append(
            {"question": question, "answer": response.answer, "sources": sources}
        )


if __name__ == "__main__":
    main()
