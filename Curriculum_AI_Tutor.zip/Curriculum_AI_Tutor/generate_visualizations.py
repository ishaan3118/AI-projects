from __future__ import annotations

import csv
from collections import Counter

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from src.config import get_config
from src.corpus_builder import CorpusBuilder
from src.utils import get_logger


def plot_chunk_distribution(records: list[dict], output_path) -> None:
    lengths = [len(r["text"].split()) for r in records]
    plt.figure(figsize=(8, 5))
    plt.hist(lengths, bins=20, color="#3b82f6", edgecolor="black")
    plt.title("Chunk Word Count Distribution")
    plt.xlabel("Words per Chunk")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()


def plot_chapter_distribution(records: list[dict], output_path) -> None:
    counts = Counter(r["chapter"] for r in records)
    labels = list(counts.keys())
    values = list(counts.values())
    plt.figure(figsize=(10, 6))
    plt.barh(labels, values, color="#10b981")
    plt.title("Chunks per Chapter")
    plt.xlabel("Number of Chunks")
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()


def plot_embedding_dimension_check(dimension: int, output_path) -> None:
    plt.figure(figsize=(5, 4))
    plt.bar(["Embedding Dimension"], [dimension], color="#f59e0b")
    plt.title("Embedding Dimension Verification")
    plt.ylabel("Dimension Size")
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()


def plot_response_time(latencies: list[float], output_path) -> None:
    plt.figure(figsize=(8, 5))
    plt.plot(range(1, len(latencies) + 1), latencies, marker="o", color="#ef4444")
    plt.title("Response Time per Evaluation Question")
    plt.xlabel("Question Index")
    plt.ylabel("Latency (seconds)")
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()


def plot_bleu_distribution(bleu_scores: list[float], output_path) -> None:
    plt.figure(figsize=(8, 5))
    plt.hist(bleu_scores, bins=10, color="#8b5cf6", edgecolor="black")
    plt.title("BLEU Score Distribution")
    plt.xlabel("BLEU Score")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()


def plot_rouge_distribution(rouge_scores: list[float], output_path) -> None:
    plt.figure(figsize=(8, 5))
    plt.hist(rouge_scores, bins=10, color="#06b6d4", edgecolor="black")
    plt.title("ROUGE-L Score Distribution")
    plt.xlabel("ROUGE-L Score")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()


def main() -> None:
    config = get_config()
    logger = get_logger("generate_visualizations", config.paths.logs_dir)

    if not config.paths.corpus_jsonl.exists():
        raise FileNotFoundError(
            "Corpus JSONL not found. Run build_index.py before generating visualizations."
        )

    corpus_builder = CorpusBuilder(config)
    records = corpus_builder.read_jsonl()

    plots_dir = config.paths.plots_dir
    plots_dir.mkdir(parents=True, exist_ok=True)

    plot_chunk_distribution(records, plots_dir / "chunk_distribution.png")
    plot_chapter_distribution(records, plots_dir / "chapter_distribution.png")
    plot_embedding_dimension_check(config.models.embedding_dimension, plots_dir / "embedding_dimension.png")

    if config.paths.evaluation_csv.exists():
        with config.paths.evaluation_csv.open("r", encoding="utf-8") as handle:
            reader = csv.DictReader(handle)
            rows = list(reader)
        latencies = [float(row["Latency"]) for row in rows]
        bleu_scores = [float(row["BLEU"]) for row in rows]
        rouge_scores = [float(row["ROUGE-L"]) for row in rows]

        plot_response_time(latencies, plots_dir / "response_time.png")
        plot_bleu_distribution(bleu_scores, plots_dir / "bleu_distribution.png")
        plot_rouge_distribution(rouge_scores, plots_dir / "rouge_distribution.png")
    else:
        logger.warning("evaluation.csv not found. Skipping evaluation-based plots.")

    logger.info("Visualizations saved to %s", plots_dir)


if __name__ == "__main__":
    main()
