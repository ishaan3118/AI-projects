from __future__ import annotations

import csv
from dataclasses import dataclass, field

import nltk
from nltk.translate.bleu_score import SmoothingFunction, sentence_bleu
from rouge_score import rouge_scorer

from src.config import AppConfig
from src.rag_pipeline import RAGPipeline
from src.utils import get_logger

try:
    nltk.data.find("tokenizers/punkt")
except LookupError:
    nltk.download("punkt", quiet=True)


@dataclass
class EvaluationQuestion:
    question: str
    reference: str
    category: str


@dataclass
class EvaluationResult:
    question: str
    reference: str
    prediction: str
    bleu: float
    rouge_l: float
    exact_match: int
    latency: float
    retrieved_chunks: str
    reviewer_comment: str
    context_precision: float = field(default=0.0)
    context_recall: float = field(default=0.0)


class RAGEvaluator:
    def __init__(self, config: AppConfig, pipeline: RAGPipeline) -> None:
        self._config = config
        self._pipeline = pipeline
        self._logger = get_logger(self.__class__.__name__, config.paths.logs_dir)
        self._rouge_scorer = rouge_scorer.RougeScorer(["rougeL"], use_stemmer=True)
        self._smoothing = SmoothingFunction().method1

    def evaluate(self, questions: list[EvaluationQuestion]) -> list[EvaluationResult]:
        results: list[EvaluationResult] = []
        for item in questions:
            response = self._pipeline.answer(item.question)
            prediction = response.answer

            bleu_score = self._compute_bleu(item.reference, prediction)
            rouge_l_score = self._compute_rouge_l(item.reference, prediction)
            exact_match = int(item.reference.strip().lower() == prediction.strip().lower())

            retrieved_texts = " | ".join(chunk.chapter for chunk in response.retrieved_chunks)
            context_precision, context_recall = self._compute_context_metrics(
                item.reference, response.retrieved_chunks
            )
            reviewer_comment = self._generate_reviewer_comment(
                bleu_score, rouge_l_score, exact_match, response.retrieved_chunks
            )

            results.append(
                EvaluationResult(
                    question=item.question,
                    reference=item.reference,
                    prediction=prediction,
                    bleu=round(bleu_score, 4),
                    rouge_l=round(rouge_l_score, 4),
                    exact_match=exact_match,
                    latency=round(response.latency_seconds, 4),
                    retrieved_chunks=retrieved_texts,
                    reviewer_comment=reviewer_comment,
                    context_precision=round(context_precision, 4),
                    context_recall=round(context_recall, 4),
                )
            )
        return results

    def _compute_bleu(self, reference: str, prediction: str) -> float:
        reference_tokens = reference.lower().split()
        prediction_tokens = prediction.lower().split()
        if not prediction_tokens:
            return 0.0
        return sentence_bleu(
            [reference_tokens], prediction_tokens, smoothing_function=self._smoothing
        )

    def _compute_rouge_l(self, reference: str, prediction: str) -> float:
        scores = self._rouge_scorer.score(reference, prediction)
        return scores["rougeL"].fmeasure

    def _compute_context_metrics(self, reference: str, retrieved_chunks) -> tuple[float, float]:
        if not retrieved_chunks:
            return 0.0, 0.0
        reference_words = set(reference.lower().split())
        relevant_count = 0
        for chunk in retrieved_chunks:
            chunk_words = set(chunk.text.lower().split())
            overlap = reference_words.intersection(chunk_words)
            if len(overlap) >= 1:
                relevant_count += 1
        precision = relevant_count / len(retrieved_chunks)
        recall = min(relevant_count / max(len(reference_words), 1), 1.0)
        return precision, recall

    def _generate_reviewer_comment(
        self, bleu_score: float, rouge_l_score: float, exact_match: int, retrieved_chunks
    ) -> str:
        if exact_match == 1:
            return "Exact match with reference. Correct, complete, and grade appropriate."
        if bleu_score >= 0.5 or rouge_l_score >= 0.5:
            return "Strong overlap with reference. Faithful to retrieved context and readable."
        if retrieved_chunks:
            return (
                "Partial overlap with reference. Answer is grounded in retrieved context "
                "but could be more complete or precise."
            )
        return "No relevant context retrieved. Review chunking or query phrasing."

    def write_csv(self, results: list[EvaluationResult], output_path) -> None:
        fieldnames = [
            "Question",
            "Reference",
            "Prediction",
            "BLEU",
            "ROUGE-L",
            "ExactMatch",
            "Latency",
            "RetrievedChunks",
            "ReviewerComment",
        ]
        with open(output_path, "w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            for result in results:
                writer.writerow(
                    {
                        "Question": result.question,
                        "Reference": result.reference,
                        "Prediction": result.prediction,
                        "BLEU": result.bleu,
                        "ROUGE-L": result.rouge_l,
                        "ExactMatch": result.exact_match,
                        "Latency": result.latency,
                        "RetrievedChunks": result.retrieved_chunks,
                        "ReviewerComment": result.reviewer_comment,
                    }
                )
        self._logger.info("Wrote evaluation results to %s", output_path)

    @staticmethod
    def summarize(results: list[EvaluationResult]) -> dict:
        if not results:
            return {"average_bleu": 0.0, "average_rouge_l": 0.0, "average_latency": 0.0}
        return {
            "average_bleu": round(sum(r.bleu for r in results) / len(results), 4),
            "average_rouge_l": round(sum(r.rouge_l for r in results) / len(results), 4),
            "average_latency": round(sum(r.latency for r in results) / len(results), 4),
            "average_context_precision": round(
                sum(r.context_precision for r in results) / len(results), 4
            ),
            "average_context_recall": round(
                sum(r.context_recall for r in results) / len(results), 4
            ),
        }
