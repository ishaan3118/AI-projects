from __future__ import annotations

import json
from pathlib import Path

from src.chunker import Chunk
from src.config import AppConfig
from src.utils import get_logger


class CorpusBuilder:
    def __init__(self, config: AppConfig) -> None:
        self._config = config
        self._logger = get_logger(self.__class__.__name__, config.paths.logs_dir)

    def write_jsonl(self, chunks: list[Chunk], output_path: Path | None = None) -> Path:
        target = output_path or self._config.paths.corpus_jsonl
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("w", encoding="utf-8") as handle:
            for chunk in chunks:
                record = {
                    "chunk_id": chunk.chunk_id,
                    "chapter": chunk.chapter,
                    "section": chunk.section,
                    "page": chunk.page,
                    "text": chunk.text,
                    "metadata": chunk.metadata,
                }
                handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        self._logger.info("Wrote %d records to %s", len(chunks), target)
        return target

    def read_jsonl(self, input_path: Path | None = None) -> list[dict]:
        source = input_path or self._config.paths.corpus_jsonl
        records: list[dict] = []
        with source.open("r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if line:
                    records.append(json.loads(line))
        return records
