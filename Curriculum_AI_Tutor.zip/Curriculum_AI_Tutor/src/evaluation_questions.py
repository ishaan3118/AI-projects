from __future__ import annotations

from src.evaluator import EvaluationQuestion

EVALUATION_QUESTIONS: list[EvaluationQuestion] = [
    EvaluationQuestion("What is crop production?", "Crop production is the process of growing plants to obtain food and other useful products.", "Definition"),
    EvaluationQuestion("Define photosynthesis.", "Photosynthesis is the process by which green plants make their own food using sunlight, water, and carbon dioxide.", "Definition"),
    EvaluationQuestion("What is meant by micro-organisms?", "Micro-organisms are tiny living things that cannot be seen without a microscope, such as bacteria, fungi, and protozoa.", "Definition"),
    EvaluationQuestion("Why do we need to conserve plants and animals?", "We need to conserve plants and animals to maintain ecological balance and protect biodiversity for future generations.", "Reasoning"),
    EvaluationQuestion("Explain why crop rotation is important.", "Crop rotation helps restore soil nutrients, reduces pest infestation, and improves soil fertility over time.", "Reasoning"),
    EvaluationQuestion("How does the force of friction affect moving objects?", "Friction opposes the relative motion between two surfaces in contact and can slow down or stop moving objects.", "Conceptual"),
    EvaluationQuestion("What happens when a force is applied to a stationary object?", "When a sufficient force is applied to a stationary object, it can start moving, change shape, or change direction.", "Conceptual"),
    EvaluationQuestion("If a metal is heated, what happens to its size?", "When a metal is heated, it generally expands because the particles gain energy and move further apart.", "Application"),
    EvaluationQuestion("A farmer wants to increase soil fertility naturally, what should be do?", "The farmer should use organic manure and practice crop rotation to naturally increase soil fertility.", "Application"),
    EvaluationQuestion("True or False: All micro-organisms are harmful to humans.", "False, many micro-organisms are useful and are used in the production of curd, bread, and medicines.", "True or False"),
    EvaluationQuestion("True or False: Friction always acts in the direction of motion.", "False, friction always acts opposite to the direction of motion.", "True or False"),
    EvaluationQuestion("Fill in the blank: The process of growing the same crop repeatedly on the same field is called _____ cropping.", "monoculture", "Fill in the blanks"),
    EvaluationQuestion("Fill in the blank: Plants prepare their food through the process of _____.", "photosynthesis", "Fill in the blanks"),
    EvaluationQuestion("What are the main components required for photosynthesis?", "Photosynthesis requires sunlight, carbon dioxide, water, and chlorophyll.", "Short Answer"),
    EvaluationQuestion("List two uses of micro-organisms.", "Micro-organisms are used to make curd from milk and to produce antibiotics like penicillin.", "Short Answer"),
    EvaluationQuestion("What is the difference between kharif and rabi crops?", "Kharif crops are grown in the rainy season while rabi crops are grown in the winter season.", "Conceptual"),
    EvaluationQuestion("Explain how irrigation helps in crop production.", "Irrigation supplies water to crops at regular intervals, which is essential for growth when rainfall is insufficient.", "Reasoning"),
    EvaluationQuestion("What is the role of decomposers in the ecosystem?", "Decomposers break down dead plants and animals into simpler substances, recycling nutrients back into the soil.", "Definition"),
    EvaluationQuestion("Why should we wear a mask while grinding wheat flour?", "Wearing a mask prevents inhalation of fine flour particles and microorganisms present in the dust.", "Reasoning"),
    EvaluationQuestion("A student observes rusting on an iron gate, which process causes this?", "Rusting occurs due to a chemical reaction between iron, oxygen, and moisture in the air.", "Application"),
]
