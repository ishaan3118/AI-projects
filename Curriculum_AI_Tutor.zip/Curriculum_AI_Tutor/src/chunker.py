from __future__ import annotations

import re
import uuid
from dataclasses import dataclass, field

from src.cleaner import CleanedPage
from src.config import AppConfig
from src.utils import get_logger


@dataclass
class Chunk:
    chunk_id: str
    chapter: str
    section: str
    page: int
    text: str
    metadata: dict = field(default_factory=dict)


class TextChunker:
    _CHAPTER_PATTERN = re.compile(
        r"^(?:chapter\s+)?(\d{1,2})[.\s]+([A-Z][A-Za-z ,'&-]{4,60})$", re.IGNORECASE
    )
    _SECTION_PATTERN = re.compile(r"^(\d{1,2}\.\d{1,2})\s+([A-Z][A-Za-z ,'&-]{2,60})$")

    def __init__(self, config: AppConfig) -> None:
        self._config = config
        self._logger = get_logger(self.__class__.__name__, config.paths.logs_dir)
        self._chunk_size = config.retrieval.chunk_size_words
        self._overlap = config.retrieval.chunk_overlap_words

    def chunk_pages(self, pages: list[CleanedPage]) -> list[Chunk]:
        current_chapter = "Introduction"
        current_section = "General"
        chunks: list[Chunk] = []

        for page in pages:
            lines = page.text.split("\n")
            buffer: list[str] = []

            for line in lines:
                chapter_match = self._CHAPTER_PATTERN.match(line.strip())
                section_match = self._SECTION_PATTERN.match(line.strip())

                if chapter_match:
                    chunks.extend(
                        self._flush_buffer(buffer, current_chapter, current_section, page.page_number)
                    )
                    buffer = []
                    current_chapter = f"{chapter_match.group(1)}. {chapter_match.group(2).strip()}"
                    current_section = "General"
                    continue

                if section_match:
                    chunks.extend(
                        self._flush_buffer(buffer, current_chapter, current_section, page.page_number)
                    )
                    buffer = []
                    current_section = f"{section_match.group(1)} {section_match.group(2).strip()}"
                    continue

                buffer.append(line)

            chunks.extend(
                self._flush_buffer(buffer, current_chapter, current_section, page.page_number)
            )

        self._logger.info("Generated %d chunks", len(chunks))
        return chunks

    def _flush_buffer(
        self, buffer: list[str], chapter: str, section: str, page_number: int
    ) -> list[Chunk]:
        text = " ".join(fragment for fragment in buffer if fragment).strip()
        if not text:
            return []
        return self._split_into_semantic_chunks(text, chapter, section, page_number)

    def _split_into_semantic_chunks(
        self, text: str, chapter: str, section: str, page_number: int
    ) -> list[Chunk]:
        words = text.split()
        if not words:
            return []

        chunks: list[Chunk] = []
        step = max(self._chunk_size - self._overlap, 1)
        for start in range(0, len(words), step):
            window = words[start : start + self._chunk_size]
            if not window:
                continue
            chunk_text = " ".join(window)
            chunk = Chunk(
                chunk_id=str(uuid.uuid4())[:8],
                chapter=chapter,
                section=section,
                page=page_number,
                text=chunk_text,
                metadata={
                    "word_count": len(window),
                    "character_count": len(chunk_text),
                },
            )
            chunks.append(chunk)
            if start + self._chunk_size >= len(words):
                break
        return chunks
