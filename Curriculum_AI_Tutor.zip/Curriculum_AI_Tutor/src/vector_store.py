from __future__ import annotations

import json
from pathlib import Path

import faiss
import numpy as np

from src.config import AppConfig
from src.utils import get_logger


class FAISSVectorStore:
    def __init__(self, config: AppConfig) -> None:
        self._config = config
        self._logger = get_logger(self.__class__.__name__, config.paths.logs_dir)
        self._index: faiss.Index | None = None
        self._metadata: list[dict] = []

    def build(self, embeddings: np.ndarray, metadata_records: list[dict]) -> None:
        if embeddings.shape[0] != len(metadata_records):
            raise ValueError("Embedding count does not match metadata count")
        dimension = embeddings.shape[1]
        index = faiss.IndexFlatIP(dimension)
        index.add(embeddings)
        self._index = index
        self._metadata = metadata_records
        self._logger.info("Built FAISS index with %d vectors, dimension %d", index.ntotal, dimension)

    def persist(self) -> None:
        if self._index is None:
            raise RuntimeError("Index has not been built yet")
        self._config.paths.faiss_index_dir.mkdir(parents=True, exist_ok=True)
        faiss.write_index(self._index, str(self._config.paths.faiss_index_file))
        with self._config.paths.faiss_metadata_file.open("w", encoding="utf-8") as handle:
            for record in self._metadata:
                handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        self._logger.info("Persisted FAISS index to %s", self._config.paths.faiss_index_file)

    def load(self) -> None:
        index_path = self._config.paths.faiss_index_file
        metadata_path = self._config.paths.faiss_metadata_file
        if not index_path.exists() or not metadata_path.exists():
            raise FileNotFoundError("FAISS index or metadata file not found. Build the index first.")
        self._index = faiss.read_index(str(index_path))
        self._metadata = []
        with metadata_path.open("r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if line:
                    self._metadata.append(json.loads(line))
        self._logger.info("Loaded FAISS index with %d vectors", self._index.ntotal)

    def search(self, query_embedding: np.ndarray, top_k: int) -> list[tuple[dict, float]]:
        if self._index is None:
            raise RuntimeError("Index has not been built or loaded")
        query_vector = query_embedding.reshape(1, -1).astype(np.float32)
        scores, indices = self._index.search(query_vector, top_k)
        results: list[tuple[dict, float]] = []
        for score, idx in zip(scores[0], indices[0]):
            if idx == -1:
                continue
            results.append((self._metadata[idx], float(score)))
        return results

    @property
    def is_ready(self) -> bool:
        return self._index is not None
