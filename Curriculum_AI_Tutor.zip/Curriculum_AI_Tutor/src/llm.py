from __future__ import annotations

from abc import ABC, abstractmethod

from src.config import AppConfig
from src.utils import get_logger


class BaseLLMClient(ABC):
    @abstractmethod
    def generate(self, prompt: str, max_new_tokens: int = 256) -> str:
        raise NotImplementedError


class OpenAILLMClient(BaseLLMClient):
    def __init__(self, config: AppConfig) -> None:
        self._config = config
        self._logger = get_logger(self.__class__.__name__, config.paths.logs_dir)
        if not config.models.openai_api_key:
            raise EnvironmentError(
                "OPENAI_API_KEY is not set. Add it to your environment or .env file."
            )
        from openai import OpenAI

        self._client = OpenAI(api_key=config.models.openai_api_key)

    def generate(self, prompt: str, max_new_tokens: int = 256) -> str:
        response = self._client.chat.completions.create(
            model=self._config.models.openai_model,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=max_new_tokens,
            temperature=0.0,
        )
        return response.choices[0].message.content.strip()


class LocalLlamaLLMClient(BaseLLMClient):
    def __init__(self, config: AppConfig) -> None:
        self._config = config
        self._logger = get_logger(self.__class__.__name__, config.paths.logs_dir)
        if not config.models.llama_model_path:
            raise EnvironmentError(
                "LLAMA_MODEL_PATH is not set. Point it to a local Llama 2 checkpoint directory."
            )
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer

        self._torch = torch
        self._tokenizer = AutoTokenizer.from_pretrained(config.models.llama_model_path)
        self._model = AutoModelForCausalLM.from_pretrained(
            config.models.llama_model_path,
            torch_dtype=torch.float32,
        )
        self._model.eval()

    def generate(self, prompt: str, max_new_tokens: int = 256) -> str:
        inputs = self._tokenizer(prompt, return_tensors="pt")
        with self._torch.no_grad():
            output_ids = self._model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                do_sample=False,
            )
        decoded = self._tokenizer.decode(output_ids[0], skip_special_tokens=True)
        return decoded[len(prompt):].strip()


class FlanT5LLMClient(BaseLLMClient):
    def __init__(self, config: AppConfig, use_lora: bool = False) -> None:
        self._config = config
        self._logger = get_logger(self.__class__.__name__, config.paths.logs_dir)
        from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

        self._tokenizer = AutoTokenizer.from_pretrained(config.models.flan_t5_base_model)
        base_model = AutoModelForSeq2SeqLM.from_pretrained(config.models.flan_t5_base_model)

        if use_lora:
            from peft import PeftModel

            adapter_path = config.paths.lora_adapter_dir
            if not adapter_path.exists():
                raise FileNotFoundError(
                    f"LoRA adapter not found at {adapter_path}. Train it first with the fine-tuning script."
                )
            self._model = PeftModel.from_pretrained(base_model, str(adapter_path))
        else:
            self._model = base_model

        self._model.eval()

    def generate(self, prompt: str, max_new_tokens: int = 256) -> str:
        inputs = self._tokenizer(prompt, return_tensors="pt", truncation=True, max_length=512)
        output_ids = self._model.generate(**inputs, max_new_tokens=max_new_tokens)
        return self._tokenizer.decode(output_ids[0], skip_special_tokens=True).strip()


def build_llm_client(config: AppConfig) -> BaseLLMClient:
    provider = config.models.llm_provider.lower()
    if provider == "openai":
        return OpenAILLMClient(config)
    if provider == "llama":
        return LocalLlamaLLMClient(config)
    if provider == "flan-t5-base":
        return FlanT5LLMClient(config, use_lora=False)
    if provider == "flan-t5-lora":
        return FlanT5LLMClient(config, use_lora=True)
    raise ValueError(f"Unsupported LLM_PROVIDER: {provider}")
