from __future__ import annotations

import re
from dataclasses import dataclass

from src.parser import ParsedPage
from src.utils import get_logger
from src.config import AppConfig


@dataclass
class CleanedPage:
    page_number: int
    text: str


class TextCleaner:
    _PAGE_NUMBER_PATTERN = re.compile(r"^\s*\d{1,4}\s*$")
    _HEADER_FOOTER_PATTERN = re.compile(
        r"(reprint\s*\d{4}-\d{2,4}|science|ncert|chapter\s+\d+)", re.IGNORECASE
    )
    _MULTI_SPACE_PATTERN = re.compile(r"[ \t]{2,}")
    _MULTI_NEWLINE_PATTERN = re.compile(r"\n{2,}")
    _BROKEN_HYPHEN_PATTERN = re.compile(r"-\n(?=[a-z])")
    _SPECIAL_CHAR_PATTERN = re.compile(r"[^\x20-\x7EA-Za-z0-9\u2018\u2019\u201c\u201d.,;:!?()'\"%\-\n ]+")

    def __init__(self, config: AppConfig) -> None:
        self._config = config
        self._logger = get_logger(self.__class__.__name__, config.paths.logs_dir)

    def clean_pages(self, pages: list[ParsedPage]) -> list[CleanedPage]:
        cleaned: list[CleanedPage] = []
        for page in pages:
            cleaned_text = self._clean_single_page(page.text)
            cleaned.append(CleanedPage(page_number=page.page_number, text=cleaned_text))
        self._logger.info("Cleaned %d pages", len(cleaned))
        return cleaned

    def _clean_single_page(self, raw_text: str) -> str:
        text = self._BROKEN_HYPHEN_PATTERN.sub("", raw_text)
        lines = text.split("\n")
        filtered_lines = []
        for line in lines:
            stripped = line.strip()
            if not stripped:
                continue
            if self._PAGE_NUMBER_PATTERN.match(stripped):
                continue
            if len(stripped) < 40 and self._HEADER_FOOTER_PATTERN.search(stripped) and len(stripped.split()) <= 4:
                continue
            filtered_lines.append(stripped)

        joined = "\n".join(filtered_lines)
        joined = self._SPECIAL_CHAR_PATTERN.sub("", joined)
        joined = self._MULTI_SPACE_PATTERN.sub(" ", joined)
        joined = self._MULTI_NEWLINE_PATTERN.sub("\n", joined)
        return joined.strip()
