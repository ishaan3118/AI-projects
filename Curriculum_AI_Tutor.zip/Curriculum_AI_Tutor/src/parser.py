from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import fitz

from src.config import AppConfig
from src.utils import get_logger


@dataclass
class ParsedPage:
    page_number: int
    text: str


class PDFParser:
    def __init__(self, config: AppConfig) -> None:
        self._config = config
        self._logger = get_logger(self.__class__.__name__, config.paths.logs_dir)

    def parse(self, pdf_path: Path) -> list[ParsedPage]:
        if not pdf_path.exists():
            raise FileNotFoundError(f"PDF not found at {pdf_path}")

        pages: list[ParsedPage] = []
        with fitz.open(pdf_path) as document:
            self._logger.info("Parsing %d pages from %s", document.page_count, pdf_path.name)
            for index in range(document.page_count):
                page = document.load_page(index)
                text = page.get_text("text")
                pages.append(ParsedPage(page_number=index + 1, text=text))
        return pages
