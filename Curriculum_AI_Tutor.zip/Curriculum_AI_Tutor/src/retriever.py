from __future__ import annotations

from dataclasses import dataclass

from src.config import AppConfig
from src.embeddings import EmbeddingGenerator
from src.utils import get_logger
from src.vector_store import FAISSVectorStore


@dataclass
class RetrievedChunk:
    chunk_id: str
    chapter: str
    section: str
    page: int
    text: str
    similarity_score: float


class FAISSRetriever:
    def __init__(
        self,
        config: AppConfig,
        embedding_generator: EmbeddingGenerator,
        vector_store: FAISSVectorStore,
    ) -> None:
        self._config = config
        self._embedding_generator = embedding_generator
        self._vector_store = vector_store
        self._logger = get_logger(self.__class__.__name__, config.paths.logs_dir)

    def retrieve(self, query: str, top_k: int | None = None) -> list[RetrievedChunk]:
        effective_top_k = top_k or self._config.retrieval.top_k
        query_embedding = self._embedding_generator.encode_single(query)
        raw_results = self._vector_store.search(query_embedding, effective_top_k)

        results: list[RetrievedChunk] = []
        for record, score in raw_results:
            if score < self._config.retrieval.similarity_threshold:
                continue
            results.append(
                RetrievedChunk(
                    chunk_id=record.get("chunk_id", ""),
                    chapter=record.get("chapter", ""),
                    section=record.get("section", ""),
                    page=record.get("page", 0),
                    text=record.get("text", ""),
                    similarity_score=round(score, 4),
                )
            )
        self._logger.info("Retrieved %d relevant chunks for query", len(results))
        return results
