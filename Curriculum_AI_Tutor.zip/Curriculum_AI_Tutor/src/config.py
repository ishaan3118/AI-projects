from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent


@dataclass(frozen=True)
class Paths:
    base_dir: Path = BASE_DIR
    data_dir: Path = BASE_DIR / "data"
    raw_dir: Path = BASE_DIR / "data" / "raw"
    processed_dir: Path = BASE_DIR / "data" / "processed"
    textbook_pdf: Path = BASE_DIR / "data" / "textbook.pdf"
    corpus_jsonl: Path = BASE_DIR / "class8_science.jsonl"
    embeddings_dir: Path = BASE_DIR / "embeddings"
    faiss_index_dir: Path = BASE_DIR / "faiss_index"
    faiss_index_file: Path = BASE_DIR / "faiss_index" / "index.faiss"
    faiss_metadata_file: Path = BASE_DIR / "faiss_index" / "metadata.jsonl"
    models_dir: Path = BASE_DIR / "models"
    lora_adapter_dir: Path = BASE_DIR / "models" / "lora_adapter"
    logs_dir: Path = BASE_DIR / "logs"
    chat_history_csv: Path = BASE_DIR / "logs" / "chat_history.csv"
    outputs_dir: Path = BASE_DIR / "outputs"
    plots_dir: Path = BASE_DIR / "outputs" / "plots"
    evaluation_dir: Path = BASE_DIR / "outputs" / "evaluation"
    evaluation_csv: Path = BASE_DIR / "evaluation.csv"

    def ensure_all(self) -> None:
        for attr_name in (
            "data_dir",
            "raw_dir",
            "processed_dir",
            "embeddings_dir",
            "faiss_index_dir",
            "models_dir",
            "logs_dir",
            "outputs_dir",
            "plots_dir",
            "evaluation_dir",
        ):
            path = getattr(self, attr_name)
            path.mkdir(parents=True, exist_ok=True)


@dataclass(frozen=True)
class ModelConfig:
    embedding_model_name: str = "sentence-transformers/all-MiniLM-L6-v2"
    embedding_dimension: int = 384
    llm_provider: str = os.getenv("LLM_PROVIDER", "openai")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    llama_model_path: str = os.getenv("LLAMA_MODEL_PATH", "")
    flan_t5_base_model: str = "google/flan-t5-small"
    random_seed: int = 42


@dataclass(frozen=True)
class RetrievalConfig:
    top_k: int = 4
    similarity_threshold: float = 0.30
    chunk_size_words: int = 180
    chunk_overlap_words: int = 30
    max_context_characters: int = 3500


@dataclass(frozen=True)
class AppConfig:
    paths: Paths = field(default_factory=Paths)
    models: ModelConfig = field(default_factory=ModelConfig)
    retrieval: RetrievalConfig = field(default_factory=RetrievalConfig)
    ncert_pdf_url: str = os.getenv(
        "NCERT_PDF_URL",
        "https://ncert.nic.in/textbook/pdf/hesc1dd.zip",
    )
    fallback_local_pdf_env_var: str = "LOCAL_TEXTBOOK_PDF_PATH"


def get_config() -> AppConfig:
    config = AppConfig()
    config.paths.ensure_all()
    return config
