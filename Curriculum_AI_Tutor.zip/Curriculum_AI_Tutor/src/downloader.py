from __future__ import annotations

import io
import os
import zipfile
from pathlib import Path

import requests

from src.config import AppConfig
from src.utils import get_logger


class TextbookDownloadError(Exception):
    pass


class TextbookDownloader:
    def __init__(self, config: AppConfig) -> None:
        self._config = config
        self._logger = get_logger(self.__class__.__name__, config.paths.logs_dir)

    def obtain_pdf(self) -> Path:
        local_override = os.getenv(self._config.fallback_local_pdf_env_var, "")
        if local_override:
            local_path = Path(local_override)
            if local_path.exists():
                self._logger.info("Using manually configured PDF path: %s", local_path)
                return self._copy_to_target(local_path)
            self._logger.warning(
                "LOCAL_TEXTBOOK_PDF_PATH was set but does not exist: %s", local_path
            )

        if self._config.paths.textbook_pdf.exists():
            self._logger.info("Textbook PDF already present at target path.")
            return self._config.paths.textbook_pdf

        try:
            return self._download_from_url()
        except Exception as exc:
            raise TextbookDownloadError(
                "Automatic download failed. Set the environment variable "
                f"{self._config.fallback_local_pdf_env_var} to a local PDF path, "
                "or place the file manually at "
                f"{self._config.paths.textbook_pdf}."
            ) from exc

    def _download_from_url(self) -> Path:
        url = self._config.ncert_pdf_url
        self._logger.info("Attempting download from %s", url)
        response = requests.get(url, timeout=60)
        response.raise_for_status()
        content_type = response.headers.get("Content-Type", "")

        self._config.paths.raw_dir.mkdir(parents=True, exist_ok=True)

        if url.endswith(".zip") or "zip" in content_type:
            with zipfile.ZipFile(io.BytesIO(response.content)) as archive:
                pdf_members = [m for m in archive.namelist() if m.lower().endswith(".pdf")]
                if not pdf_members:
                    raise TextbookDownloadError("Downloaded archive did not contain a PDF file.")
                extracted_path = archive.extract(pdf_members[0], path=self._config.paths.raw_dir)
                extracted_file = Path(extracted_path)
        else:
            extracted_file = self._config.paths.raw_dir / "downloaded_textbook.pdf"
            extracted_file.write_bytes(response.content)

        return self._copy_to_target(extracted_file)

    def _copy_to_target(self, source: Path) -> Path:
        target = self._config.paths.textbook_pdf
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(source.read_bytes())
        self._logger.info("Textbook PDF ready at %s", target)
        return target
