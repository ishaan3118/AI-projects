from __future__ import annotations

import time
from dataclasses import dataclass, field

from src.config import AppConfig
from src.llm import BaseLLMClient
from src.logger import InteractionLogger
from src.memory import ConversationMemory
from src.prompt import FALLBACK_RESPONSE, PromptBuilder
from src.retriever import FAISSRetriever, RetrievedChunk
from src.utils import get_logger


@dataclass
class RAGResponse:
    answer: str
    chapter: str
    retrieved_chunks: list[RetrievedChunk] = field(default_factory=list)
    latency_seconds: float = 0.0


class RAGPipeline:
    def __init__(
        self,
        config: AppConfig,
        retriever: FAISSRetriever,
        llm_client: BaseLLMClient,
        interaction_logger: InteractionLogger | None = None,
        memory: ConversationMemory | None = None,
    ) -> None:
        self._config = config
        self._retriever = retriever
        self._llm_client = llm_client
        self._prompt_builder = PromptBuilder(config)
        self._interaction_logger = interaction_logger
        self._memory = memory or ConversationMemory()
        self._logger = get_logger(self.__class__.__name__, config.paths.logs_dir)

    def answer(self, question: str, top_k: int | None = None) -> RAGResponse:
        start_time = time.perf_counter()
        error_message = ""
        try:
            retrieved_chunks = self._retriever.retrieve(question, top_k=top_k)
            if not retrieved_chunks:
                answer_text = FALLBACK_RESPONSE
                chapter = ""
            else:
                prompt = self._prompt_builder.build(question, retrieved_chunks)
                answer_text = self._llm_client.generate(prompt)
                chapter = retrieved_chunks[0].chapter
            self._memory.add(question, answer_text)
        except Exception as exc:
            error_message = str(exc)
            answer_text = FALLBACK_RESPONSE
            chapter = ""
            retrieved_chunks = []
            self._logger.exception("RAG pipeline failed for question: %s", question)

        latency = time.perf_counter() - start_time

        if self._interaction_logger is not None:
            retrieved_summary = "; ".join(
                f"{chunk.chapter}/{chunk.section} (p.{chunk.page}, score={chunk.similarity_score})"
                for chunk in retrieved_chunks
            )
            self._interaction_logger.log(
                question=question,
                retrieved_documents=retrieved_summary,
                answer=answer_text,
                latency_seconds=latency,
                error=error_message,
            )

        return RAGResponse(
            answer=answer_text,
            chapter=chapter,
            retrieved_chunks=retrieved_chunks,
            latency_seconds=latency,
        )
