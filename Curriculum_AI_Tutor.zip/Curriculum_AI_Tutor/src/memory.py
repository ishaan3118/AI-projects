from __future__ import annotations

from collections import deque
from dataclasses import dataclass


@dataclass
class Turn:
    question: str
    answer: str


class ConversationMemory:
    def __init__(self, max_turns: int = 5) -> None:
        self._turns: deque[Turn] = deque(maxlen=max_turns)

    def add(self, question: str, answer: str) -> None:
        self._turns.append(Turn(question=question, answer=answer))

    def as_context_string(self) -> str:
        if not self._turns:
            return ""
        lines = [f"Q: {turn.question}\nA: {turn.answer}" for turn in self._turns]
        return "\n\n".join(lines)

    def clear(self) -> None:
        self._turns.clear()

    def history(self) -> list[Turn]:
        return list(self._turns)
