from __future__ import annotations

import numpy as np
from sentence_transformers import SentenceTransformer

from src.config import AppConfig
from src.utils import get_logger


class EmbeddingGenerator:
    def __init__(self, config: AppConfig) -> None:
        self._config = config
        self._logger = get_logger(self.__class__.__name__, config.paths.logs_dir)
        self._model = SentenceTransformer(config.models.embedding_model_name)

    def encode(self, texts: list[str], batch_size: int = 32) -> np.ndarray:
        if not texts:
            return np.zeros((0, self._config.models.embedding_dimension), dtype=np.float32)
        self._logger.info("Encoding %d texts", len(texts))
        embeddings = self._model.encode(
            texts,
            batch_size=batch_size,
            show_progress_bar=False,
            convert_to_numpy=True,
        )
        embeddings = embeddings.astype(np.float32)
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        normalized = embeddings / norms
        return normalized

    def encode_single(self, text: str) -> np.ndarray:
        return self.encode([text])[0]
