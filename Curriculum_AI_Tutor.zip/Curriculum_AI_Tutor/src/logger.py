from __future__ import annotations

import csv
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from src.config import AppConfig
from src.utils import get_logger


@dataclass
class InteractionRecord:
    timestamp: str
    question: str
    retrieved_documents: str
    answer: str
    latency_seconds: float
    error: str


class InteractionLogger:
    _FIELDNAMES = [
        "timestamp",
        "question",
        "retrieved_documents",
        "answer",
        "latency_seconds",
        "error",
    ]

    def __init__(self, config: AppConfig) -> None:
        self._config = config
        self._logger = get_logger(self.__class__.__name__, config.paths.logs_dir)
        self._csv_path = config.paths.chat_history_csv
        self._ensure_header()

    def _ensure_header(self) -> None:
        self._csv_path.parent.mkdir(parents=True, exist_ok=True)
        if not self._csv_path.exists():
            with self._csv_path.open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=self._FIELDNAMES)
                writer.writeheader()

    def log(
        self,
        question: str,
        retrieved_documents: str,
        answer: str,
        latency_seconds: float,
        error: str = "",
    ) -> None:
        record = InteractionRecord(
            timestamp=datetime.now(timezone.utc).isoformat(),
            question=question,
            retrieved_documents=retrieved_documents,
            answer=answer,
            latency_seconds=round(latency_seconds, 4),
            error=error,
        )
        with self._csv_path.open("a", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=self._FIELDNAMES)
            writer.writerow(record.__dict__)
        self._logger.info("Logged interaction for question: %s", question[:60])
