from __future__ import annotations

from src.config import AppConfig
from src.retriever import RetrievedChunk

FALLBACK_RESPONSE = (
    "I am focused on NCERT Class 8 Science. Please rephrase your question "
    "or ask something from the syllabus."
)

_SYSTEM_INSTRUCTIONS = (
    "You are a friendly AI tutor for NCERT Class 8 Science students. "
    "Answer strictly and only using the provided context excerpts. "
    "Never hallucinate, never invent facts, and never answer using "
    "information that is not present in the context. Use simple language "
    "suitable for a Class 8 student. If the context does not contain "
    "enough information to answer the question, respond with exactly: "
    f'"{FALLBACK_RESPONSE}"'
)


class PromptBuilder:
    def __init__(self, config: AppConfig) -> None:
        self._config = config

    def build(self, question: str, retrieved_chunks: list[RetrievedChunk]) -> str:
        if not retrieved_chunks:
            return self._build_empty_context_prompt(question)

        context_sections = []
        remaining_characters = self._config.retrieval.max_context_characters
        for chunk in retrieved_chunks:
            excerpt = chunk.text
            if remaining_characters <= 0:
                break
            excerpt = excerpt[:remaining_characters]
            remaining_characters -= len(excerpt)
            context_sections.append(
                f"[Chapter: {chunk.chapter} | Section: {chunk.section} | Page: {chunk.page}]\n{excerpt}"
            )

        context_block = "\n\n".join(context_sections)
        return (
            f"{_SYSTEM_INSTRUCTIONS}\n\n"
            f"Context:\n{context_block}\n\n"
            f"Question: {question}\n\n"
            "Answer:"
        )

    def _build_empty_context_prompt(self, question: str) -> str:
        return (
            f"{_SYSTEM_INSTRUCTIONS}\n\n"
            "Context:\n(no relevant context was retrieved)\n\n"
            f"Question: {question}\n\n"
            "Answer:"
        )
