from __future__ import annotations

import json

from src.config import get_config
from src.embeddings import EmbeddingGenerator
from src.evaluation_questions import EVALUATION_QUESTIONS
from src.evaluator import RAGEvaluator
from src.llm import build_llm_client
from src.logger import InteractionLogger
from src.rag_pipeline import RAGPipeline
from src.retriever import FAISSRetriever
from src.utils import get_logger, set_global_seed
from src.vector_store import FAISSVectorStore


def main() -> None:
    config = get_config()
    set_global_seed(config.models.random_seed)
    logger = get_logger("run_evaluation", config.paths.logs_dir)

    embedder = EmbeddingGenerator(config)
    vector_store = FAISSVectorStore(config)
    vector_store.load()
    retriever = FAISSRetriever(config, embedder, vector_store)
    llm_client = build_llm_client(config)
    interaction_logger = InteractionLogger(config)
    pipeline = RAGPipeline(config, retriever, llm_client, interaction_logger)

    evaluator = RAGEvaluator(config, pipeline)
    results = evaluator.evaluate(EVALUATION_QUESTIONS)
    evaluator.write_csv(results, config.paths.evaluation_csv)
    evaluator.write_csv(results, config.paths.evaluation_dir / "evaluation.csv")

    summary = evaluator.summarize(results)
    summary_path = config.paths.evaluation_dir / "summary.json"
    with summary_path.open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2)

    logger.info("Evaluation summary: %s", summary)


if __name__ == "__main__":
    main()
