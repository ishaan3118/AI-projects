# Curriculum-Based AI Tutor — Project Report

## Project Overview

The Curriculum-Based AI Tutor is a Retrieval-Augmented Generation (RAG)
chatbot scoped to the NCERT Class 8 Science textbook. Its goal is to give
students accurate, syllabus-grounded answers while explicitly refusing to
answer questions outside that scope, avoiding the hallucination risk of an
open-domain chatbot in an educational setting.

## Architecture

```
                +----------------+
                |  Textbook PDF  |
                +--------+-------+
                         |
                         v
                +----------------+
                |   PDF Parser   |  (PyMuPDF)
                +--------+-------+
                         v
                +----------------+
                |  Text Cleaner  |  headers, footers, page numbers removed
                +--------+-------+
                         v
                +------------------------+
                | Chapter / Section      |
                | Detector + Chunker     |
                +--------+---------------+
                         v
                +----------------+
                | Embedding Model|  sentence-transformers/all-MiniLM-L6-v2
                +--------+-------+
                         v
                +----------------+
                |  FAISS Index   |  cosine similarity via inner product
                +--------+-------+
                         v
   Question --> Retriever --> Prompt Builder --> LLM --> Answer + Citations
                                                    |
                                                    v
                                          Interaction Logger + Evaluator
```

## Dataset

The pipeline ingests the official NCERT Class 8 Science textbook PDF,
downloaded automatically when reachable or supplied manually via
`LOCAL_TEXTBOOK_PDF_PATH`. Text is extracted page by page, cleaned of
headers, footers, page numbers, and non-informative special characters,
then segmented by detected chapter and section headings before being split
into overlapping word-based chunks. The result is persisted as
`class8_science.jsonl`, where every record carries `chapter`, `section`,
`page`, `chunk_id`, `text`, and `metadata` fields.

## Methodology

### RAG Workflow

1. The user's question is embedded with the same model used for the corpus.
2. FAISS performs a cosine-similarity search (via normalized inner product)
   over the indexed chunks and returns the top-K matches above a
   configurable similarity threshold.
3. A prompt template instructs the LLM to answer only from the retrieved
   context, in simple Class 8-appropriate language, and to return a fixed
   fallback sentence when the context is insufficient.
4. The LLM generates the answer, which is returned alongside the source
   chapter, retrieved snippets, and similarity scores.
5. Every interaction is logged with timestamp, question, retrieved
   documents, answer, latency, and any error.

### Embedding Model

`sentence-transformers/all-MiniLM-L6-v2` was chosen for its balance of
speed and retrieval quality on short educational passages, and because it
runs comfortably on CPU, which matters for a classroom deployment without
guaranteed GPU access. Embeddings are L2-normalized so that FAISS inner
product search is equivalent to cosine similarity.

### Retriever

A flat FAISS index (`IndexFlatIP`) is used for exact nearest-neighbor
search. At the corpus size of a single subject textbook, exact search is
fast enough that approximate indexing is unnecessary, and it avoids the
recall loss that approximate methods can introduce.

### LLM

The LLM layer is provider-agnostic through a small abstract base class,
supporting OpenAI's GPT-4.1/GPT-3.5 family via API key, a locally hosted
Llama 2 checkpoint, and FLAN-T5-Small in both its base and LoRA-fine-tuned
forms. Provider selection is entirely configuration-driven; no code changes
are required to switch.

### Optional Fine-Tuning

A LoRA adapter can be trained on top of `google/flan-t5-small` using PEFT.
Approximately 100 question-answer pairs are auto-generated from corpus
sections (using the first sentence of each eligible chunk as a proxy
answer) and used as a lightweight supervised fine-tuning set. This is
intended as a demonstration of parameter-efficient fine-tuning rather than
a replacement for the primary retrieval-grounded pipeline.

## Evaluation Metrics

A 20-question evaluation set spans definition, conceptual, reasoning,
application, true/false, fill-in-the-blank, and short-answer question
types. Each answer is scored with:

- **BLEU** — n-gram precision against a reference answer
- **ROUGE-L** — longest common subsequence overlap
- **Exact Match** — strict string match
- **Latency** — end-to-end response time
- **Context Precision / Recall** — approximate lexical-overlap proxy for
  how much of the retrieved context was relevant, and how much of the
  reference answer's vocabulary was covered by retrieval

Results are written to `evaluation.csv` with a reviewer comment per row
covering correctness, completeness, readability, faithfulness, and grade
appropriateness, plus averaged summary metrics.

## Results

Quantitative results depend on which LLM provider is configured and on the
actual textbook PDF used to build the index, since NCERT periodically
revises chapter numbering and content. Run `python run_evaluation.py`
against a built index to populate `evaluation.csv` and `outputs/plots/`
with the six required visualizations (chunk distribution, chapter
distribution, embedding dimension verification, response time, BLEU
distribution, ROUGE-L distribution) for your specific configuration.

## Limitations

- Context precision/recall are computed with lexical overlap rather than a
  learned faithfulness model; they are directional signals, not ground
  truth.
- Chapter and section detection relies on regex pattern matching against
  heading formatting. If NCERT's PDF layout changes, the patterns in
  `src/chunker.py` need adjustment.
- The auto-generated LoRA fine-tuning QA pairs use a simple heuristic
  (first sentence of a chunk) rather than a curated question bank, so the
  fine-tuned model's answer style may not match a human-authored gold set.
- Automatic PDF download depends on NCERT's hosting being reachable and
  the URL pattern remaining stable; a manual fallback path is provided.

## Future Work

- Add a hybrid BM25 + dense retrieval strategy to improve recall on short,
  keyword-heavy questions.
- Introduce an LLM-based faithfulness judge to complement lexical metrics.
- Expand the fine-tuning QA set with human-curated pairs.
- Add multi-language support for regional NCERT textbook editions.

## Conclusion

The system delivers a complete, modular RAG pipeline scoped tightly to a
single textbook, with syllabus-boundary refusal, source citation, and a
full evaluation harness. The architecture is intentionally decoupled at
each stage (parsing, cleaning, chunking, embedding, retrieval, prompting,
generation, evaluation) so that any single component — embedding model,
LLM provider, or retrieval backend — can be swapped without touching the
rest of the system.
