from __future__ import annotations

import json
import random
from pathlib import Path

from datasets import Dataset
from peft import LoraConfig, TaskType, get_peft_model
from transformers import (
    AutoModelForSeq2SeqLM,
    AutoTokenizer,
    DataCollatorForSeq2Seq,
    Seq2SeqTrainer,
    Seq2SeqTrainingArguments,
)

from src.config import get_config
from src.corpus_builder import CorpusBuilder
from src.utils import get_logger, set_global_seed


class QAPairGenerator:
    def __init__(self, min_words: int = 25) -> None:
        self._min_words = min_words

    def generate(self, records: list[dict], target_count: int = 100) -> list[dict]:
        eligible = [r for r in records if len(r["text"].split()) >= self._min_words]
        random.shuffle(eligible)
        selected = eligible[:target_count]

        pairs = []
        for record in selected:
            first_sentence = record["text"].split(".")[0].strip()
            question = f"What does the section '{record['section']}' explain about {record['chapter']}?"
            answer = first_sentence if first_sentence else record["text"][:200]
            pairs.append({"question": question, "answer": answer, "context": record["text"]})
        return pairs


def build_dataset(pairs: list[dict], tokenizer) -> Dataset:
    def format_example(example: dict) -> dict:
        input_text = f"question: {example['question']} context: {example['context']}"
        model_inputs = tokenizer(input_text, max_length=384, truncation=True)
        labels = tokenizer(text_target=example["answer"], max_length=64, truncation=True)
        model_inputs["labels"] = labels["input_ids"]
        return model_inputs

    dataset = Dataset.from_list(pairs)
    return dataset.map(format_example, remove_columns=dataset.column_names)


def main() -> None:
    config = get_config()
    set_global_seed(config.models.random_seed)
    logger = get_logger("finetune_lora", config.paths.logs_dir)

    corpus_builder = CorpusBuilder(config)
    records = corpus_builder.read_jsonl()
    if not records:
        raise RuntimeError("Corpus is empty. Run build_index.py before fine-tuning.")

    qa_generator = QAPairGenerator()
    pairs = qa_generator.generate(records, target_count=100)

    qa_dataset_path = config.paths.processed_dir / "lora_qa_pairs.jsonl"
    qa_dataset_path.parent.mkdir(parents=True, exist_ok=True)
    with qa_dataset_path.open("w", encoding="utf-8") as handle:
        for pair in pairs:
            handle.write(json.dumps(pair, ensure_ascii=False) + "\n")
    logger.info("Generated %d QA pairs for fine-tuning", len(pairs))

    tokenizer = AutoTokenizer.from_pretrained(config.models.flan_t5_base_model)
    base_model = AutoModelForSeq2SeqLM.from_pretrained(config.models.flan_t5_base_model)

    lora_config = LoraConfig(
        task_type=TaskType.SEQ_2_SEQ_LM,
        r=8,
        lora_alpha=16,
        lora_dropout=0.05,
        target_modules=["q", "v"],
    )
    peft_model = get_peft_model(base_model, lora_config)

    tokenized_dataset = build_dataset(pairs, tokenizer)
    data_collator = DataCollatorForSeq2Seq(tokenizer=tokenizer, model=peft_model)

    training_args = Seq2SeqTrainingArguments(
        output_dir=str(config.paths.models_dir / "lora_checkpoints"),
        per_device_train_batch_size=4,
        num_train_epochs=3,
        learning_rate=1e-3,
        logging_steps=10,
        save_strategy="no",
        seed=config.models.random_seed,
        report_to=[],
    )

    trainer = Seq2SeqTrainer(
        model=peft_model,
        args=training_args,
        train_dataset=tokenized_dataset,
        data_collator=data_collator,
    )
    trainer.train()

    config.paths.lora_adapter_dir.mkdir(parents=True, exist_ok=True)
    peft_model.save_pretrained(str(config.paths.lora_adapter_dir))
    tokenizer.save_pretrained(str(config.paths.lora_adapter_dir))
    logger.info("LoRA adapter saved to %s", config.paths.lora_adapter_dir)


if __name__ == "__main__":
    main()
