from __future__ import annotations

from pathlib import Path

import fitz
import pytest

from src.config import get_config
from src.parser import PDFParser


@pytest.fixture()
def sample_pdf(tmp_path: Path) -> Path:
    pdf_path = tmp_path / "sample.pdf"
    document = fitz.open()
    page = document.new_page()
    page.insert_text((72, 72), "Chapter 1 Crop Production and Management")
    document.save(pdf_path)
    document.close()
    return pdf_path


def test_parse_returns_expected_page_count(sample_pdf: Path) -> None:
    config = get_config()
    parser = PDFParser(config)
    pages = parser.parse(sample_pdf)
    assert len(pages) == 1
    assert "Crop Production" in pages[0].text


def test_parse_missing_file_raises(tmp_path: Path) -> None:
    config = get_config()
    parser = PDFParser(config)
    with pytest.raises(FileNotFoundError):
        parser.parse(tmp_path / "missing.pdf")
