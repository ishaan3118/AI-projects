from __future__ import annotations

from src.config import get_config
from src.llm import BaseLLMClient
from src.prompt import FALLBACK_RESPONSE
from src.rag_pipeline import RAGPipeline
from src.retriever import RetrievedChunk


class FakeRetriever:
    def __init__(self, chunks: list[RetrievedChunk]) -> None:
        self._chunks = chunks

    def retrieve(self, query: str, top_k: int | None = None) -> list[RetrievedChunk]:
        return self._chunks


class FakeLLMClient(BaseLLMClient):
    def generate(self, prompt: str, max_new_tokens: int = 256) -> str:
        return "Photosynthesis is how plants make food using sunlight."


def test_pipeline_returns_fallback_when_no_context() -> None:
    config = get_config()
    retriever = FakeRetriever([])
    llm_client = FakeLLMClient()
    pipeline = RAGPipeline(config, retriever, llm_client)
    response = pipeline.answer("What is quantum entanglement?")
    assert response.answer == FALLBACK_RESPONSE
    assert response.retrieved_chunks == []


def test_pipeline_returns_llm_answer_when_context_available() -> None:
    config = get_config()
    chunk = RetrievedChunk(
        chunk_id="c1",
        chapter="4. Photosynthesis",
        section="4.1",
        page=25,
        text="Plants use sunlight, water, and carbon dioxide to make food.",
        similarity_score=0.9,
    )
    retriever = FakeRetriever([chunk])
    llm_client = FakeLLMClient()
    pipeline = RAGPipeline(config, retriever, llm_client)
    response = pipeline.answer("What is photosynthesis?")
    assert "Photosynthesis" in response.answer
    assert response.chapter == "4. Photosynthesis"
