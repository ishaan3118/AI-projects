from __future__ import annotations

import pytest

from src.config import get_config
from src.embeddings import EmbeddingGenerator
from src.retriever import FAISSRetriever
from src.vector_store import FAISSVectorStore


@pytest.fixture(scope="module")
def populated_store() -> tuple:
    config = get_config()
    embedder = EmbeddingGenerator(config)
    records = [
        {"chunk_id": "a1", "chapter": "1. Crop Production", "section": "1.1", "page": 1, "text": "Crop production involves growing plants for food."},
        {"chunk_id": "a2", "chapter": "6. Combustion and Flame", "section": "6.1", "page": 40, "text": "Combustion is a chemical process in which a substance reacts with oxygen."},
    ]
    embeddings = embedder.encode([r["text"] for r in records])
    store = FAISSVectorStore(config)
    store.build(embeddings, records)
    return config, embedder, store


def test_retrieve_returns_relevant_chunk(populated_store: tuple) -> None:
    config, embedder, store = populated_store
    retriever = FAISSRetriever(config, embedder, store)
    results = retriever.retrieve("What is combustion?", top_k=1)
    assert len(results) == 1
    assert "Combustion" in results[0].chapter


def test_retrieve_respects_top_k(populated_store: tuple) -> None:
    config, embedder, store = populated_store
    retriever = FAISSRetriever(config, embedder, store)
    results = retriever.retrieve("Tell me about plants and food", top_k=2)
    assert len(results) <= 2
