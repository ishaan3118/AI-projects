from __future__ import annotations

import numpy as np
import pytest

from src.config import get_config
from src.embeddings import EmbeddingGenerator


@pytest.fixture(scope="module")
def embedder() -> EmbeddingGenerator:
    config = get_config()
    return EmbeddingGenerator(config)


def test_encode_returns_normalized_vectors(embedder: EmbeddingGenerator) -> None:
    texts = ["Photosynthesis is the process by which plants make food.", "Friction opposes motion."]
    embeddings = embedder.encode(texts)
    assert embeddings.shape[0] == 2
    norms = np.linalg.norm(embeddings, axis=1)
    assert np.allclose(norms, 1.0, atol=1e-3)


def test_encode_empty_list_returns_empty_array(embedder: EmbeddingGenerator) -> None:
    embeddings = embedder.encode([])
    assert embeddings.shape[0] == 0
