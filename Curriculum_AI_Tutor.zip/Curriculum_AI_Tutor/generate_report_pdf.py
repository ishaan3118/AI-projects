from __future__ import annotations

import re
from pathlib import Path

from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    ListFlowable,
    ListItem,
    Paragraph,
    Preformatted,
    SimpleDocTemplate,
    Spacer,
)

BASE_DIR = Path(__file__).resolve().parent
SOURCE_MD = BASE_DIR / "REPORT.md"
TARGET_PDF = BASE_DIR / "REPORT.pdf"


def build_styles() -> dict:
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="H1Custom",
            parent=styles["Heading1"],
            spaceBefore=18,
            spaceAfter=10,
        )
    )
    styles.add(
        ParagraphStyle(
            name="H2Custom",
            parent=styles["Heading2"],
            spaceBefore=14,
            spaceAfter=8,
        )
    )
    styles.add(
        ParagraphStyle(
            name="BodyCustom",
            parent=styles["Normal"],
            fontSize=10.5,
            leading=15,
            spaceAfter=8,
        )
    )
    styles.add(
        ParagraphStyle(
            name="CodeCustom",
            parent=styles["Code"],
            fontSize=8,
            leading=10,
        )
    )
    return styles


def inline_markdown_to_reportlab(text: str) -> str:
    text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    text = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", text)
    text = re.sub(r"`(.+?)`", r"<font face='Courier'>\1</font>", text)
    return text


def parse_markdown(markdown_text: str, styles: dict) -> list:
    story = []
    lines = markdown_text.split("\n")
    index = 0
    list_buffer: list[str] = []
    code_buffer: list[str] = []
    in_code_block = False

    def flush_list():
        nonlocal list_buffer
        if list_buffer:
            items = [
                ListItem(Paragraph(inline_markdown_to_reportlab(item), styles["BodyCustom"]))
                for item in list_buffer
            ]
            story.append(ListFlowable(items, bulletType="bullet", leftIndent=18))
            story.append(Spacer(1, 6))
            list_buffer = []

    while index < len(lines):
        line = lines[index]
        stripped = line.strip()

        if stripped.startswith("```"):
            if in_code_block:
                story.append(Preformatted("\n".join(code_buffer), styles["CodeCustom"]))
                story.append(Spacer(1, 8))
                code_buffer = []
                in_code_block = False
            else:
                flush_list()
                in_code_block = True
            index += 1
            continue

        if in_code_block:
            code_buffer.append(line)
            index += 1
            continue

        if stripped.startswith("# "):
            flush_list()
            story.append(Paragraph(inline_markdown_to_reportlab(stripped[2:]), styles["Title"]))
        elif stripped.startswith("## "):
            flush_list()
            story.append(Paragraph(inline_markdown_to_reportlab(stripped[3:]), styles["H1Custom"]))
        elif stripped.startswith("### "):
            flush_list()
            story.append(Paragraph(inline_markdown_to_reportlab(stripped[4:]), styles["H2Custom"]))
        elif stripped.startswith("- "):
            list_buffer.append(stripped[2:])
        elif stripped.startswith("|"):
            flush_list()
            story.append(Paragraph(inline_markdown_to_reportlab(stripped), styles["CodeCustom"]))
        elif stripped == "":
            flush_list()
            story.append(Spacer(1, 4))
        else:
            flush_list()
            story.append(Paragraph(inline_markdown_to_reportlab(stripped), styles["BodyCustom"]))

        index += 1

    flush_list()
    return story


def main() -> None:
    markdown_text = SOURCE_MD.read_text(encoding="utf-8")
    styles = build_styles()
    story = parse_markdown(markdown_text, styles)

    document = SimpleDocTemplate(
        str(TARGET_PDF),
        pagesize=letter,
        topMargin=0.75 * inch,
        bottomMargin=0.75 * inch,
        leftMargin=0.75 * inch,
        rightMargin=0.75 * inch,
        title="Curriculum-Based AI Tutor Report",
    )
    document.build(story)


if __name__ == "__main__":
    main()
